# Product Image Assets

The website now uses your PNG product photos in these groups.

Resin Art, 7 slots:

- `assets/res-1.png`
- `assets/res-2.png`
- `assets/res-3.png`
- `assets/res-4.png`
- `assets/res-5.png`
- `assets/res-6.png`
- `assets/res-7.png`

Saree Pre-Pleating, 10 slots:

- `assets/s-1.png`
- `assets/s-2.png`
- `assets/s-3.png`
- `assets/s-4.png`
- `assets/s-5.png`
- `assets/s-6.png`
- `assets/s-7.png`
- `assets/s-8.png`
- `assets/s-9.png`
- `assets/s-10.png`

Aksharabhyasam Slate, 4 slots:

- `assets/a-slate.png`
- `assets/a-slate-1.png`
- `assets/a-slate-2.png`
- `assets/a-slate-3.png`

Pelli Addutera's, 8 slots:

- `assets/at.png`
- `assets/at-1.png`
- `assets/at-2.png`
- `assets/at-3.png`
- `assets/at-4.png`
- `assets/at-5.png`
- `assets/at-6.png`
- `assets/at-7.png`

The carousel reads the image paths from `store_of_craft_website.html`. To add or remove product photos later, edit the matching `<img>` lines for that product.
